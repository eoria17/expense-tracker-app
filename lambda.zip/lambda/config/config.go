package config

const (
	ACCESS_KEY_ID     = "AKIAYYWNQAX2MCBD2VXM"
	SECRET_ACCESS_KEY = "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"
	AWS_TOKEN         = ""
	AWS_BUCKET_NAME   = "expense-tracker-thumbnail-bucket"
	AWS_IMG_PATH      = "https://expense-tracker-thumbnail-bucket.s3-ap-southeast-2.amazonaws.com/"
	AWS_REGION        = "ap-southeast-2"
)
