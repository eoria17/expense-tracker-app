package main

import (
	"bytes"
	"errors"
	"fmt"
	"image"
	"image/jpeg"
	"lambda-function/config"
	"math"
	"net/http"
	"time"

	"github.com/aws/aws-lambda-go/lambda"
	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/credentials"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/s3/s3manager"
	"github.com/nfnt/resize"
)

type Response struct {
	ThumbnailURL string `json:"thumbnailurl"`
}

func main() {
	//create AWS session
	creds := credentials.NewStaticCredentials(config.ACCESS_KEY_ID, config.SECRET_ACCESS_KEY, "")
	creds.Get()

	sess, err := session.NewSession(&aws.Config{
		Region:      aws.String(config.AWS_REGION),
		Credentials: creds,
	})

	if err != nil {
		fmt.Println(err)
	}

	//s3 image upload
	s3uploader := s3manager.NewUploader(sess)

	engine := AppEngine{
		S3Uploader: s3uploader,
	}

	lambda.Start(engine.ImageResize)
}

func (ae AppEngine) ImageResize(event InputEvent) (map[string]string, error) {
	response, err := http.Get(event.ImageURL)
	if err != nil {
		return nil, errors.New("image does not exist in the bucket, " + err.Error())
	}
	defer response.Body.Close()

	if response.StatusCode != 200 {
		fmt.Println("Received non 200 response code")
		return nil, errors.New("received non 200 response code")
	}

	img, _, err := image.Decode(response.Body)
	if err != nil {
		fmt.Println(err)
	}

	b := img.Bounds()
	width := b.Max.X
	height := b.Max.Y

	w, h := calculateRatioFit(width, height)

	m := resize.Resize(uint(w), uint(h), img, resize.Lanczos3)

	buffer := new(bytes.Buffer)
	jpeg.Encode(buffer, m, nil)

	//upload to thumbnail bucket
	_, err = ae.S3Uploader.Upload(&s3manager.UploadInput{
		Bucket:      aws.String(config.AWS_BUCKET_NAME),
		Key:         aws.String("thumb_" + time.Now().Format("02-01-2006_15:04:05") + ".jpg"),
		Body:        bytes.NewReader(buffer.Bytes()),
		ContentType: aws.String("image/jpeg"),
		ACL:         aws.String("public-read"),
	})

	if err != nil {
		fmt.Println(err)
	}

	now := time.Now()

	respMap := make(map[string]string)
	respMap["thumbnailurl"] = config.AWS_IMG_PATH + "thumb_" + now.Format("02-01-2006") + "_" + now.Format("15") + "%3A" + now.Format("04") + "%3A" + now.Format("05") + ".jpg"

	return respMap, nil
}

const DEFAULT_MAX_WIDTH float64 = 320
const DEFAULT_MAX_HEIGHT float64 = 240

//Calculate the size of the image after scaling
func calculateRatioFit(srcWidth, srcHeight int) (int, int) {
	ratio := math.Min(DEFAULT_MAX_WIDTH/float64(srcWidth), DEFAULT_MAX_HEIGHT/float64(srcHeight))
	return int(math.Ceil(float64(srcWidth) * ratio)), int(math.Ceil(float64(srcHeight) * ratio))
}

func DownloadImage(URL string) []byte {
	response, err := http.Get(URL)
	if err != nil {
		fmt.Println(err)
	}
	defer response.Body.Close()

	if response.StatusCode != 200 {
		fmt.Println("Received non 200 response code")
		return nil
	}

	image, _, err := image.Decode(response.Body)
	if err != nil {
		fmt.Println(err)
	}

	buffer := new(bytes.Buffer)
	jpeg.Encode(buffer, image, nil)

	return buffer.Bytes()
}

type InputEvent struct {
	ImageURL string `json:"imageurl"`
}

type AppEngine struct {
	S3Uploader *s3manager.Uploader
}
