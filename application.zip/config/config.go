package config

import (
	"fmt"

	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

func Open(host string, dbname string, user string, password string, port string) (store *Storage, err error) {
	string_param := fmt.Sprintf("host=%s port=%s user=%s dbname=%s sslmode=disable password=%s", host, port, user, dbname, password)
	db, err := gorm.Open(postgres.Open(string_param))

	store = &Storage{
		DB: db,
	}

	return
}

type Storage struct {
	DB *gorm.DB
}

const (
	DB_ADAPTER  = "postgres"
	DB_HOST     = "expense-tracker-db.cpt8vwxbowqh.ap-southeast-2.rds.amazonaws.com"
	DB_USER     = "postgres"
	DB_PASSWORD = "database"
	DB_NAME     = "expense-db"
	DB_SSLMODE  = "disable"
	DB_PORT     = "5432"

	ACCESS_KEY_ID       = "AKIAYYWNQAX2MCBD2VXM"
	SECRET_ACCESS_KEY   = "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"
	AWS_TOKEN           = ""
	AWS_BUCKET_NAME     = "expense-tracker-bucket"
	AWS_IMG_PATH        = "https://expense-tracker-bucket.s3-ap-southeast-2.amazonaws.com/"
	AWS_REGION          = "ap-southeast-2"
	AWS_API_TRANSACTION = "https://ypzlmbzi2i.execute-api.ap-southeast-2.amazonaws.com/test"

	SESSION_KEY = "passphrasewhichneedstobe32bytes!"

	HEADER_PATH     = "views/_header.html"
	NAVIGATION_PATH = "views/_navigation.html"
)
